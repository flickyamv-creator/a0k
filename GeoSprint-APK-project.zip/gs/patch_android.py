"""Run after `npx cap add android`: landscape lock, immersive fullscreen, notch support."""
import re, pathlib, glob
root = pathlib.Path('android/app/src/main')

# 1. landscape + keep state on rotate
m = root / 'AndroidManifest.xml'
t = m.read_text()
if 'screenOrientation' not in t:
    t = t.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"', 1)
m.write_text(t)

# 2. fullscreen + display cutout in theme
s = root / 'res/values/styles.xml'
t = s.read_text()
items = ('<item name="android:windowFullscreen">true</item>\n'
         '        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>\n'
         '        <item name="android:windowBackground">@android:color/black</item>\n')
t = re.sub(r'(<style name="AppTheme\.NoActionBar"[^>]*>)', lambda mo: mo.group(1) + '\n        ' + items, t, count=1)
s.write_text(t)

# 3. immersive sticky mode (hide nav bar) + allow audio without gesture
java = glob.glob(str(root / 'java/**/MainActivity.java'), recursive=True)[0]
j = pathlib.Path(java)
t = j.read_text()
pkg = re.search(r'package\s+([\w.]+);', t).group(1)
j.write_text(f'''package {pkg};

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
    @Override
    public void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WebSettings ws = this.bridge.getWebView().getSettings();
        ws.setMediaPlaybackRequiresUserGesture(false);
        this.bridge.getWebView().setOverScrollMode(View.OVER_SCROLL_NEVER);
        hideBars();
    }}

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {{
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }}

    private void hideBars() {{
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }}
}}
''')
print('android patched')
