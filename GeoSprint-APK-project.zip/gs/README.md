# GeoSprint – mobile / APK project

`www/index.html` is the mobile-optimized game (touch controls, landscape fit, notch-safe, PWA).

## Get the APK (no Android Studio needed) – ~5 minutes
1. Create a free GitHub account → New repository (private is fine).
2. Upload everything in this folder (drag & drop into the repo page; keep the `.github` folder).
3. Open the **Actions** tab → *Build GeoSprint APK* → **Run workflow**.
4. When it finishes (~4–6 min), open the run → **Artifacts → GeoSprint-apk** → unzip → `app-debug.apk`.
5. Copy it to your phone, open it, allow "Install unknown apps" when asked.

## Or build locally (Android Studio + Node 18+)
    npm install
    npx cap add android
    python3 patch_android.py
    npx capacitor-assets generate --android
    npx cap sync android
    npx cap open android     # Build > Build APK(s)

## Or skip the APK: install as an app
Host `www/` on any HTTPS site (GitHub Pages, Netlify), open it in Chrome on Android → ⋮ → *Install app*.

## Touch controls
◀ ▶ move, ⚔ attack (boss fight), JUMP jumps. They mirror keys A/D, F and Space, so keyboard still works.
Tap menu buttons directly on the screen.
